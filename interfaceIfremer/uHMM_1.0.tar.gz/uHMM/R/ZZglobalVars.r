#.onLoad <- function(libname = find.package("uHMM"), pkgname = "uHMM") {
#  uHMMinterface()
#}

globalVariables(c("CstateSeq","CsymbolSeq","selectedNames","estimatedHMM","symbCentersNorm","symbCenters","normParams","uHMMenv",
                  "nbSymbols","gap","MstateSeq","trainingRows","MarelCarnot"
                  ))